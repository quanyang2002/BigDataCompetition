from flask import Flask
from .home import home

def create_app():
    app = Flask(__name__, template_folder='./app/templates')
    app.config.from_object(__name__)
    app.register_blueprint(home)
    return app
