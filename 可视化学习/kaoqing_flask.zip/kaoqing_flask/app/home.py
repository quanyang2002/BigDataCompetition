import copy
import pandas as pd
from flask import Blueprint, jsonify
from flask import render_template

# 定义数据存储类
class DataStore:
    data = None

# 定义一个全局变量
global dataStore

# 实例化类DataStore()
dataStore = DataStore()
# 将pandas读取到的数据存储到 DataStore()的类变量dada
dataStore.data = pd.read_csv("./punchcard.csv")

# 定义一个蓝图,并指定template目录
home = Blueprint('home', __name__, template_folder='templates')


@home.route('/')
def index():
    return render_template('index.html')


# 为蓝图创建路由,地址为/stacked,允许的请求方法有GET请求
@home.route(rule='/stacked', methods=['GET'])
def stacked_bar():
    """
    为堆叠柱状图准备数据
    """
    data = dataStore.data
    # 获取所有课程
    courseList = data['course'].unique().tolist()
    # 用于生成echarts的series
    seriesDict = {
        'name': '',
        'type': 'bar',
        'stack': 'total',
        'label': {
            'show': True
        },
        'emphasis': {
            'focus': 'series'
        },
        'data': []
    }
    seriesList = []
    # 遍历打卡时的表情
    for expression in data['expression'].dropna().unique().tolist():
        # 取出指定expression的数据集,并统计该expression不同课程的人数
        course = data[data['expression'] == expression]['course'].value_counts().to_dict()
        # 将字典按照键进行排序
        course = dict(sorted(course.items(), key=lambda x: x[0]))
        # 将容器内数据备份一份到新的地址，这里一定要使用copy,否则只会拷贝原始数据的内存地址
        series = seriesDict.copy()
        series['name'] = expression
        series['data'] = list(course.values())
        seriesList.append(series)
    return jsonify(courseList=courseList, seriesList=seriesList)


@home.route(rule='/dash_board', methods=['GET'])
def dash_board():
    data, gaugeData = dataStore.data, []
    # 定义仪表盘所需数据
    gaugeDict = {
        # 仪表盘显示的数值(百分比)
        "value": 0,
        # 标签值
        "name": '',
        "title": {
            # 仪表盘中央标题位置
            "offsetCenter": []
        },
        "detail": {
            "valueAnimation": True,
            # 仪表盘中央详情数据位置
            "offsetCenter": []
        }
    }
    offsetCenter = [
        # [垂直(上为负),水平(左为负)]
        ['-30%', '-45%'],
        ['-30%', '-33%'],
        ['30%', '-45%'],
        ['30%', '-33%'],
        ['-30%', '0%'],
        ['-30%', '13%'],
        ['30%', '0%'],
        ['30%', '13%'],
        ['0%', '30%'],
        ['0%', '43%']
    ]
    # 根据班级和打卡信息分组
    new = data.groupby(["class", "card_in"]).size().to_frame().reset_index()
    for class_ in data['class'].unique().tolist():
        new1 = new[new['class'] == class_]
        # 计算每个班级的出勤率
        value = round((new1[new1['card_in'] == 1][0] / new1[0].sum() * 100).values[0], 2)
        # 由于gaugeDict中含有列表,这里要使用深拷贝
        gauge = copy.deepcopy(gaugeDict)
        gauge['value'] = value
        gauge['name'] = class_
        gauge['title']["offsetCenter"] = offsetCenter.pop(0)
        gauge['detail']["offsetCenter"] = offsetCenter.pop(0)
        gaugeData.append(gauge)
    return jsonify(gaugeData=gaugeData)

@home.route(rule='/pie', methods=['GET'])
def pie():
    data, series = dataStore.data, []
    # 取出上课地点和课程列,并去除重复数据
    new = data[['address', 'course']].drop_duplicates()
    # 计算不同地点的课程数目
    new = new.groupby("address").count().reset_index()
    new = new.T.to_dict()
    for key in new.keys():
        dict_ = {
            "name": new[key]['address'],
            "value": new[key]['course']
        }
        series.append(dict_)
    return jsonify(series=series, borderRadius=len(series))