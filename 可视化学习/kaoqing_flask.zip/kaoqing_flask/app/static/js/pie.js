let pie = echarts.init(document.getElementById('pie'));
let option2;

option2 = {
    // 设置图例的位置和文字样式
    legend: {
        top: 'bottom',
        textStyle: {
            color: "white"
        }
    },
    // 设置提示框样式
    tooltip: {
        trigger: 'item',
        /*
        * a:对应series中的name
        * b:对应data中的name
        * c:对应data中的value
        * */
        formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    series: [
        {
            name: '课程数目',
            type: 'pie',
            // [内圈半径,外圈半径]
            radius: [80, 200],
            // 圆心在图中的位置
            center: ['50%', '50%'],
            roseType: 'area',
            itemStyle: {
                borderRadius: 0
            },
            data: []
        }
    ]
};

option2 && pie.setOption(option2);

// 异步加载数据
$.get('/pie').done(function (data) {
    pie.hideLoading(); // 隐藏加载动画

    // 填入数据
    pie.setOption({
        series: [
            {
                itemStyle: {
                    borderRadius: data.borderRadius
                },
                data: data.series
            }
        ]
    });
});