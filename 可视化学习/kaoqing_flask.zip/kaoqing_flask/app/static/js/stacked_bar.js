// 获取id为stacked_bar的DOM
let chartDom = document.getElementById('stacked_bar');
// 创建一个echarts实例,并设置挂载的DOM以及主题
let myChart = echarts.init(chartDom);
let option;
// 设置echarts配置项
option = {
    // 提示框组件
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    // 图例组件
    legend: {
        textStyle:{
            color:"white"
        }
    },
    /* grid配置项
    * show:是否显示直角坐标系网格
    *left:图表离容器左侧的距离
    * backgroundColor:网格背景色，默认透明
    * borderColor:网格的边框颜色
    * borderWidth:网格的边框线宽
    * containLabel:grid 区域是否包含坐标轴的刻度标签。（用于避免坐标轴上名称过长导致溢出现象）
    * */
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis: {
        type: 'value',
        axisLabel:{//修改坐标系字体颜色
            show:true,
            textStyle:{
                color:"white"
            }
        }
    },
    /* y轴配置项
    * data:设置y轴上的值
    * */
    yAxis: {
        type: 'category',
        axisLabel:{//修改坐标系字体颜色
            show:true,
            textStyle:{
                color:"white"
            }
        },
        data: []
    },
    /* series配置项
    * name:legend对应的名称
    * type:图形类型
    * stack:若多个值一样，则堆叠到一起
    * data:数据
    * emphasis:高亮设置
    * */
    series: []
};

// option不为空时，设置上面实例化的echarts的option
option && myChart.setOption(option);

// 异步加载数据
$.get('/stacked').done(function (data) {
    myChart.hideLoading(); // 隐藏加载动画

    // 填入数据
    myChart.setOption({
        yAxis: {
            data: data.courseList
        },
        series: data.seriesList
    });
});