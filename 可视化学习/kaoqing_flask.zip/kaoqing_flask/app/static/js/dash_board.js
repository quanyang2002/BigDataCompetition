// 获取DOM并实例化一个Echarts
let dash_board = echarts.init(document.getElementById('dash_board'));
let option1;

option1 = {
    series: [
        {
            // 图像类型
            type: 'gauge',
            // 开始角度、结束角度
            startAngle: 90,
            endAngle: -360,
            // 指针配置项
            pointer: {
                show: false
            },
            // 进度条配置项
            progress: {
                show: true,
                overlap: false,
                roundCap: true,
                clip: true,
                itemStyle: {
                    borderWidth: 1,
                    borderColor: '#464646'
                }
            },
            // 仪表盘轴相关配置
            axisLine: {
                lineStyle: {
                    width: 50,
                }
            },
            // 进度条(大)刻度样式
            splitLine: {
                show: true,
                distance: 0,
                length: 10
            },
            // 进度条(小)刻度样式
            axisTick: {
                show: true
            },
            // 大刻度标签
            axisLabel: {
                show: true,
                distance: 60,// 标签与刻度间的距离
                color: 'white'
            },
            data: [],
            // 仪表盘中央详情数据标题配置
            title: {
                fontSize: 14,
                color: 'white'
            },
            // 仪表盘中间详情配置
            detail: {
                width: 50,
                height: 14,
                fontSize: 14,
                color: 'auto',
                borderColor: 'auto',
                borderRadius: 20,
                borderWidth: 1,
                formatter: '{value}%'
            }
        }
    ]
};
option1 && dash_board.setOption(option1);

// 异步加载数据
$.get('/dash_board').done(function (data) {
    dash_board.hideLoading(); // 隐藏加载动画

    // 填入数据
    dash_board.setOption({
        series: [{
            data:data.gaugeData
        }]
    });
});